import unittest

from reference import (
    AI_ORDER,
    EMPTY,
    O,
    X,
    choose_ai_move,
    is_terminal,
    place,
    reachable_boards,
    starter_for_totals,
    winner,
    winning_moves,
)


class RulesAndAiTest(unittest.TestCase):
    def test_all_reachable_ai_turns_choose_one_legal_deterministic_move(self) -> None:
        checked = 0
        for starter in (X, O):
            for board, turn in reachable_boards(starter):
                if turn != O or is_terminal(board):
                    continue
                move = choose_ai_move(board)
                self.assertEqual(EMPTY, board[move])
                self.assertEqual(move, choose_ai_move(board))
                checked += 1
        self.assertGreater(checked, 1000)

    def test_immediate_win_has_priority_over_block(self) -> None:
        board = (O, O, EMPTY, X, X, EMPTY, EMPTY, EMPTY, EMPTY)
        self.assertEqual(2, choose_ai_move(board))

    def test_every_reachable_immediate_win_or_block_uses_tie_order(self) -> None:
        order = {cell: index for index, cell in enumerate(AI_ORDER)}
        for starter in (X, O):
            for board, turn in reachable_boards(starter):
                if turn != O or is_terminal(board):
                    continue
                wins = winning_moves(board, O)
                blocks = winning_moves(board, X)
                if wins:
                    self.assertEqual(min(wins, key=order.__getitem__), choose_ai_move(board))
                elif blocks:
                    self.assertEqual(min(blocks, key=order.__getitem__), choose_ai_move(board))

    def test_ai_is_intentionally_beatable_when_player_starts(self) -> None:
        def player_can_force_win(board: tuple[int, ...], turn: int) -> bool:
            result = winner(board)
            if result:
                return result == X
            if EMPTY not in board:
                return False
            if turn == O:
                return player_can_force_win(place(board, choose_ai_move(board), O), X)
            return any(
                player_can_force_win(place(board, index, X), O)
                for index, value in enumerate(board)
                if value == EMPTY
            )

        self.assertTrue(player_can_force_win((EMPTY,) * 9, X))

    def test_terminal_board_rejects_ai_move(self) -> None:
        with self.assertRaisesRegex(ValueError, "terminal board"):
            choose_ai_move((X, X, X, O, O, EMPTY, EMPTY, EMPTY, EMPTY))

    def test_completed_totals_alternate_starter(self) -> None:
        self.assertEqual(X, starter_for_totals(0, 0, 0))
        self.assertEqual(O, starter_for_totals(1, 0, 0))
        self.assertEqual(X, starter_for_totals(1, 1, 0))
        self.assertEqual(O, starter_for_totals(12, 7, 4))


if __name__ == "__main__":
    unittest.main()

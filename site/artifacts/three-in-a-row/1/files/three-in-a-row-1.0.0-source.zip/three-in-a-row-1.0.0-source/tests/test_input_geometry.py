import unittest

from reference import CELL_COLUMNS, CELL_ROWS, cell_at, command_at, rising_edges


class InputGeometryTest(unittest.TestCase):
    def test_every_board_pixel_maps_to_exactly_one_cell(self) -> None:
        counts = [0] * 9
        for y in range(200):
            for x in range(320):
                cell = cell_at(x, y)
                if cell is not None:
                    counts[cell] += 1
        self.assertEqual([57 * 47] * 9, counts)

    def test_cell_centres_and_boundaries_map_deterministically(self) -> None:
        for row, (top, bottom) in enumerate(CELL_ROWS):
            for column, (left, right) in enumerate(CELL_COLUMNS):
                expected = row * 3 + column
                for point in (
                    (left, top),
                    (right, top),
                    (left, bottom),
                    (right, bottom),
                    ((left + right) // 2, (top + bottom) // 2),
                ):
                    self.assertEqual(expected, cell_at(*point))

    def test_outside_and_gap_pixels_do_not_place(self) -> None:
        for point in ((0, 0), (9, 36), (181, 36), (10, 35), (10, 177), (319, 199)):
            self.assertIsNone(cell_at(*point))

    def test_touch_commands_have_disjoint_stable_bounds(self) -> None:
        self.assertEqual("new", command_at(194, 145))
        self.assertEqual("new", command_at(247, 169))
        self.assertEqual("help", command_at(254, 145))
        self.assertEqual("help", command_at(307, 169))
        for point in ((193, 145), (248, 145), (253, 145), (308, 145), (250, 157)):
            self.assertIsNone(command_at(*point))

    def test_held_click_emits_only_one_rising_edge(self) -> None:
        self.assertEqual(
            [False, True, False, False, False, False, True, False],
            rising_edges((0, 1, 1, 1, 0, 0, 1, 0)),
        )


if __name__ == "__main__":
    unittest.main()

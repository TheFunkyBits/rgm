import tempfile
from pathlib import Path
import sys
import unittest
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from package import FIXED_TIME, write_zip


class PackageTest(unittest.TestCase):
    def test_canonical_zip_sorts_paths_and_carries_no_extras(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "test.zip"
            write_zip(
                output,
                [
                    ("root/Z.TXT", b"z", False),
                    ("root/A.COM", b"a", True),
                ],
            )
            with zipfile.ZipFile(output) as archive:
                self.assertEqual(["root/A.COM", "root/Z.TXT"], archive.namelist())
                self.assertEqual(b"", archive.comment)
                for entry in archive.infolist():
                    self.assertEqual(FIXED_TIME, entry.date_time)
                    self.assertEqual(b"", entry.extra)
                    self.assertEqual(b"", entry.comment)
                    self.assertEqual(zipfile.ZIP_STORED, entry.compress_type)


if __name__ == "__main__":
    unittest.main()

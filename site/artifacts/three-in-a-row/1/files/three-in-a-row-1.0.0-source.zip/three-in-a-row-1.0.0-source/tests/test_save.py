import unittest

from reference import (
    MAX_COUNTER,
    crc16_ccitt_false,
    decode_save,
    encode_save,
    saturating_increment,
)


class SaveTest(unittest.TestCase):
    def test_standard_crc_vector(self) -> None:
        self.assertEqual(0x29B1, crc16_ccitt_false(b"123456789"))

    def test_round_trip_boundary_values(self) -> None:
        for values in ((0, 0, 0), (1, 7, 12), (MAX_COUNTER, MAX_COUNTER, MAX_COUNTER)):
            encoded = encode_save(*values)
            self.assertEqual(12, len(encoded))
            self.assertEqual(values, decode_save(encoded))

    def test_invalid_magic_length_trailing_and_crc_are_rejected(self) -> None:
        valid = bytearray(encode_save(12, 7, 4))
        mutations = (
            b"",
            bytes(valid[:-1]),
            bytes(valid) + b"x",
            b"BAD!" + bytes(valid[4:]),
            bytes(valid[:5] + bytes([valid[5] ^ 1]) + valid[6:]),
        )
        for value in mutations:
            self.assertIsNone(decode_save(value))

    def test_out_of_range_counters_are_rejected(self) -> None:
        for values in ((-1, 0, 0), (0, MAX_COUNTER + 1, 0)):
            with self.assertRaisesRegex(ValueError, "uint16"):
                encode_save(*values)

    def test_increment_saturates(self) -> None:
        self.assertEqual(1, saturating_increment(0))
        self.assertEqual(MAX_COUNTER, saturating_increment(MAX_COUNTER - 1))
        self.assertEqual(MAX_COUNTER, saturating_increment(MAX_COUNTER))


if __name__ == "__main__":
    unittest.main()

from collections.abc import Iterable
import struct


EMPTY = 0
X = 1
O = 2

LINES = (
    (0, 1, 2),
    (3, 4, 5),
    (6, 7, 8),
    (0, 3, 6),
    (1, 4, 7),
    (2, 5, 8),
    (0, 4, 8),
    (2, 4, 6),
)

AI_ORDER = (4, 0, 8, 2, 6, 1, 5, 7, 3)
CORNERS = (0, 8, 2, 6)
SIDES = (1, 5, 7, 3)
OPPOSITE_CORNERS = ((8, 0), (0, 8), (6, 2), (2, 6))

CELL_COLUMNS = ((10, 66), (67, 123), (124, 180))
CELL_ROWS = ((36, 82), (83, 129), (130, 176))
NEW_BUTTON = (194, 145, 247, 169)
HELP_BUTTON = (254, 145, 307, 169)

SAVE_MAGIC = b"TIR1"
SAVE_SIZE = 12
MAX_COUNTER = 0xFFFF


def winner(board: tuple[int, ...]) -> int:
    winners = {
        board[first]
        for first, second, third in LINES
        if board[first] != EMPTY and board[first] == board[second] == board[third]
    }
    if len(winners) > 1:
        raise ValueError("board has two winners")
    return next(iter(winners), EMPTY)


def winning_line(board: tuple[int, ...]) -> int | None:
    for index, (first, second, third) in enumerate(LINES):
        if board[first] != EMPTY and board[first] == board[second] == board[third]:
            return index
    return None


def is_terminal(board: tuple[int, ...]) -> bool:
    return winner(board) != EMPTY or EMPTY not in board


def place(board: tuple[int, ...], index: int, mark: int) -> tuple[int, ...]:
    if index not in range(9) or mark not in (X, O) or board[index] != EMPTY:
        raise ValueError("illegal move")
    mutable = list(board)
    mutable[index] = mark
    return tuple(mutable)


def winning_moves(board: tuple[int, ...], mark: int) -> list[int]:
    return [
        index
        for index in AI_ORDER
        if board[index] == EMPTY and winner(place(board, index, mark)) == mark
    ]


def fork_moves(board: tuple[int, ...], mark: int) -> list[int]:
    result = []
    for index in AI_ORDER:
        if board[index] != EMPTY:
            continue
        candidate = place(board, index, mark)
        if len(winning_moves(candidate, mark)) >= 2:
            result.append(index)
    return result


def choose_ai_move(board: tuple[int, ...]) -> int:
    if is_terminal(board):
        raise ValueError("terminal board")

    immediate = winning_moves(board, O)
    if immediate:
        return immediate[0]
    blocks = winning_moves(board, X)
    if blocks:
        return blocks[0]
    forks = fork_moves(board, O)
    if forks:
        return forks[0]
    if board[4] == EMPTY:
        return 4
    for player_corner, opposite in OPPOSITE_CORNERS:
        if board[player_corner] == X and board[opposite] == EMPTY:
            return opposite
    for index in CORNERS:
        if board[index] == EMPTY:
            return index
    for index in SIDES:
        if board[index] == EMPTY:
            return index
    raise ValueError("no legal move")


def reachable_boards(starter: int) -> set[tuple[tuple[int, ...], int]]:
    initial = (EMPTY,) * 9
    result: set[tuple[tuple[int, ...], int]] = set()

    def visit(board: tuple[int, ...], turn: int) -> None:
        key = (board, turn)
        if key in result:
            return
        result.add(key)
        if is_terminal(board):
            return
        next_turn = O if turn == X else X
        for index, value in enumerate(board):
            if value == EMPTY:
                visit(place(board, index, turn), next_turn)

    visit(initial, starter)
    return result


def starter_for_totals(wins: int, draws: int, losses: int) -> int:
    return X if (wins + draws + losses) % 2 == 0 else O


def cell_at(x: int, y: int) -> int | None:
    column = next(
        (index for index, (left, right) in enumerate(CELL_COLUMNS) if left <= x <= right),
        None,
    )
    row = next(
        (index for index, (top, bottom) in enumerate(CELL_ROWS) if top <= y <= bottom),
        None,
    )
    return None if column is None or row is None else row * 3 + column


def command_at(x: int, y: int) -> str | None:
    for name, (left, top, right, bottom) in (
        ("new", NEW_BUTTON),
        ("help", HELP_BUTTON),
    ):
        if left <= x <= right and top <= y <= bottom:
            return name
    return None


def rising_edges(buttons: Iterable[int]) -> list[bool]:
    previous = False
    result = []
    for value in buttons:
        pressed = bool(value & 1)
        result.append(pressed and not previous)
        previous = pressed
    return result


def crc16_ccitt_false(value: bytes) -> int:
    crc = 0xFFFF
    for byte in value:
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if crc & 0x8000 else (crc << 1) & 0xFFFF
    return crc


def encode_save(wins: int, draws: int, losses: int) -> bytes:
    if any(value not in range(MAX_COUNTER + 1) for value in (wins, draws, losses)):
        raise ValueError("counter outside uint16 range")
    payload = SAVE_MAGIC + struct.pack("<HHH", wins, draws, losses)
    return payload + struct.pack("<H", crc16_ccitt_false(payload))


def decode_save(value: bytes) -> tuple[int, int, int] | None:
    if len(value) != SAVE_SIZE or value[:4] != SAVE_MAGIC:
        return None
    expected_crc = struct.unpack_from("<H", value, 10)[0]
    if crc16_ccitt_false(value[:10]) != expected_crc:
        return None
    return struct.unpack_from("<HHH", value, 4)


def saturating_increment(value: int) -> int:
    if value not in range(MAX_COUNTER + 1):
        raise ValueError("counter outside uint16 range")
    return min(value + 1, MAX_COUNTER)

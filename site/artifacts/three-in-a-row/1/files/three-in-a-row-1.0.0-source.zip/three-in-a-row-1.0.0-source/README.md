# Three in a Row

Three in a Row is an original one-player tic-tac-toe game for 8086-compatible DOS systems. It runs at 320x200, accepts direct mouse input and keyboard controls, and stores completed-round win, draw, and loss totals locally.

## Controls

- Mouse or touch: focus and mark a board cell; select New or Help.
- Arrow keys: move focus.
- Enter: mark the focused cell or start the next round.
- F1: open or close help.
- Escape: close help or exit.

The computer follows a deterministic tactical policy. It takes wins, blocks immediate losses, creates forks, and prefers strong board positions, but it is intentionally beatable.

## Distribution

Generated executables and release archives are not committed. Release artifacts are built reproducibly from this source and published with SHA-256 checksums and provenance.

Copyright (c) 2026 The Funky Bits. Licensed under the MIT License.

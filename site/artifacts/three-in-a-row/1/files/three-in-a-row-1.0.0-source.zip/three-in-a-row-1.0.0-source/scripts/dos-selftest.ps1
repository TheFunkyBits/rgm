[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Binary,
    [string]$DosBox
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 3.0

if ([string]::IsNullOrWhiteSpace($DosBox)) {
    $DosBox = if ($env:DOSBOX_X) {
        $env:DOSBOX_X
    } else {
        Join-Path $PSScriptRoot `
            '..\..\.tools\dosbox-x-2026.07.02\bin\x64\Release SDL2\dosbox-x.exe'
    }
}

$binaryPath = [IO.Path]::GetFullPath($Binary)
if (-not (Test-Path -LiteralPath $binaryPath -PathType Leaf)) {
    throw "Self-test binary is missing: $binaryPath"
}
if (-not (Test-Path -LiteralPath $DosBox -PathType Leaf)) {
    throw "Pinned DOSBox-X is missing: $DosBox"
}
$directory = Split-Path $binaryPath -Parent
$name = Split-Path $binaryPath -Leaf
$configuration = Join-Path $directory 'dosbox-selftest.conf'
$log = Join-Path $directory 'dosbox-selftest.log'
$pass = Join-Path $directory 'THREE.OK'
$fail = Join-Path $directory 'THREE.BAD'
$save = Join-Path $directory 'THREE.DAT'
$temporarySave = Join-Path $directory 'THREE.NEW'
Remove-Item $pass,$fail,$save,$temporarySave,$log -Force -ErrorAction SilentlyContinue

@"
[sdl]
fullscreen = false
waitonerror = false

[log]
logfile = $log

[autoexec]
mount c $directory
c:
$name
exit
"@ | Set-Content -LiteralPath $configuration -Encoding ascii

$process = Start-Process -FilePath $DosBox -ArgumentList @('-conf', $configuration) -PassThru
try {
    Wait-Process -Id $process.Id -Timeout 15 -ErrorAction SilentlyContinue
    $process.Refresh()
    if (-not $process.HasExited) { throw 'DOS self-test exceeded 15 seconds.' }
    if (Test-Path -LiteralPath $fail) { throw 'DOS self-test reported failure.' }
    if (-not (Test-Path -LiteralPath $pass)) { throw 'DOS self-test produced no success marker.' }
    if ((Test-Path -LiteralPath $save) -or (Test-Path -LiteralPath $temporarySave)) {
        throw 'DOS self-test left save files behind.'
    }
    Get-Content -LiteralPath $pass
} finally {
    if (-not $process.HasExited) { Stop-Process -Id $process.Id -Force }
    Remove-Item $configuration,$log,$pass,$fail -Force -ErrorAction SilentlyContinue
}

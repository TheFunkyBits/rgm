[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Cover,
    [Parameter(Mandatory = $true)][string]$Gameplay,
    [Parameter(Mandatory = $true)][string]$Statistics,
    [Parameter(Mandatory = $true)][string]$OutputDirectory
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version 3.0
Add-Type -AssemblyName System.Drawing.Common

function Export-Frame([string]$InputPath, [string]$OutputPath) {
    $source = [Drawing.Bitmap]::FromFile([IO.Path]::GetFullPath($InputPath))
    try {
        if ($source.Width -ne 320 -or $source.Height -ne 200) {
            throw "Source frame must be exactly 320x200: $InputPath"
        }
        $destination = [Drawing.Bitmap]::new(
            1280,
            960,
            [Drawing.Imaging.PixelFormat]::Format24bppRgb
        )
        try {
            $graphics = [Drawing.Graphics]::FromImage($destination)
            try {
                $graphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
                $graphics.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::Half
                $graphics.DrawImage($source, 0, 0, 1280, 960)
            } finally {
                $graphics.Dispose()
            }
            $destination.Save($OutputPath, [Drawing.Imaging.ImageFormat]::Png)
        } finally {
            $destination.Dispose()
        }
    } finally {
        $source.Dispose()
    }
}

$output = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Path $output -Force | Out-Null
Export-Frame $Cover (Join-Path $output 'cover.png')
Export-Frame $Gameplay (Join-Path $output 'gameplay.png')
Export-Frame $Statistics (Join-Path $output 'statistics.png')

#!/usr/bin/env python3

import argparse
import filecmp
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
IGNORED = shutil.ignore_patterns(".git", "build", "dist", "__pycache__", "*.pyc")


def compare_files(first: Path, second: Path, names: tuple[str, ...]) -> None:
    for name in names:
        left = first / name
        right = second / name
        if not filecmp.cmp(left, right, shallow=False):
            raise RuntimeError(f"Reproducibility mismatch: {name}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--keep", action="store_true")
    arguments = parser.parse_args()
    temporary = Path(tempfile.mkdtemp(prefix="three-in-a-row-repro-"))
    try:
        roots = (temporary / "short" / "project", temporary / "long-path" / "nested" / "project")
        for root in roots:
            shutil.copytree(ROOT, root, ignore=IGNORED)
            subprocess.run(
                [sys.executable, "scripts/package.py", "--output", "dist", "--build", "build/release"],
                cwd=root,
                check=True,
                capture_output=True,
                text=True,
            )
        compare_files(
            roots[0] / "build" / "release",
            roots[1] / "build" / "release",
            ("THREE.COM", "THREE.LST", "THREE-build-receipt.json"),
        )
        compare_files(
            roots[0] / "dist",
            roots[1] / "dist",
            (
                "three-in-a-row-1.0.0-dos.zip",
                "three-in-a-row-1.0.0-source.zip",
                "provenance.json",
                "SHA256SUMS.txt",
            ),
        )
    finally:
        if not arguments.keep:
            shutil.rmtree(temporary, ignore_errors=True)
    print("Three in a Row reproducibility verified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3

import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
LOCK_PATH = ROOT / "toolchain.lock.json"
MAX_COM_BYTES = 0xFF00


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_lock() -> dict:
    with LOCK_PATH.open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if value.get("schemaVersion") != 1:
        raise RuntimeError("Unsupported toolchain lock schema")
    return value


def resolve_yasm(lock: dict) -> Path:
    sdk_root = os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME")
    if not sdk_root:
        local_app_data = os.environ.get("LOCALAPPDATA")
        if not local_app_data:
            raise RuntimeError("Set ANDROID_SDK_ROOT or LOCALAPPDATA")
        sdk_root = str(Path(local_app_data) / "Android" / "Sdk")

    host = "windows" if platform.system() == "Windows" else "linux"
    host_lock = lock.get(host)
    if not host_lock:
        raise RuntimeError(f"No locked Yasm toolchain for {host}")

    yasm = (
        Path(sdk_root)
        / "ndk"
        / lock["androidNdkVersion"]
        / host_lock["relativePath"]
    )
    if not yasm.is_file():
        raise RuntimeError(f"Locked Yasm is missing: {yasm}")
    actual_hash = sha256(yasm)
    if actual_hash != host_lock["sha256"]:
        raise RuntimeError(
            f"Locked Yasm hash differs: {actual_hash} != {host_lock['sha256']}"
        )
    version = subprocess.run(
        [str(yasm), "--version"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
    if f"yasm {lock['yasmVersion']}" not in version:
        raise RuntimeError(f"Locked Yasm version differs: {version.splitlines()[0]}")
    return yasm


def source_inventory() -> list[dict]:
    return [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        }
        for path in sorted((ROOT / "src").glob("*"))
        if path.is_file() and path.suffix.lower() in {".asm", ".inc"}
    ]


def normalize_listing(path: Path) -> None:
    value = path.read_text(encoding="utf-8")
    roots = {
        str(ROOT),
        str(ROOT).replace("\\", "/"),
    }
    for root in sorted(roots, key=len, reverse=True):
        value = value.replace(root, ".")
    path.write_text(value, encoding="utf-8", newline="\n")


def build(output_root: Path, test_build: bool = False) -> dict:
    lock = read_lock()
    yasm = resolve_yasm(lock)
    output_root.mkdir(parents=True, exist_ok=True)
    stem = "TIRTEST" if test_build else "THREE"
    output = output_root / f"{stem}.COM"
    listing = output_root / f"{stem}.LST"
    source = ROOT / "src" / "three.asm"

    environment = os.environ.copy()
    environment.pop("YASMENV", None)
    command = [
        str(yasm),
        "-p",
        "nasm",
        "-f",
        "bin",
        "-I" + str(ROOT / "src") + os.sep,
    ]
    if test_build:
        command.append("-dTEST_BUILD=1")
    command += [
        "-l",
        str(listing),
        "-o",
        str(output),
        str(source),
    ]
    result = subprocess.run(
        command,
        cwd=ROOT,
        env=environment,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0 or result.stdout.strip() or result.stderr.strip():
        raise RuntimeError(
            "Yasm emitted diagnostics:\n" + result.stdout + result.stderr
        )
    if not output.is_file() or not listing.is_file():
        raise RuntimeError("Yasm did not produce the COM image and listing")
    normalize_listing(listing)
    if output.stat().st_size == 0 or output.stat().st_size > MAX_COM_BYTES:
        raise RuntimeError(f"Invalid COM image size: {output.stat().st_size}")

    receipt = {
        "schemaVersion": 1,
        "tool": {
            "androidNdkVersion": lock["androidNdkVersion"],
            "yasmVersion": lock["yasmVersion"],
            "sha256": sha256(yasm),
        },
        "testBuild": test_build,
        "sources": source_inventory(),
        "output": {
            "path": output.name,
            "bytes": output.stat().st_size,
            "sha256": sha256(output),
        },
        "listing": {
            "path": listing.name,
            "bytes": listing.stat().st_size,
            "sha256": sha256(listing),
        },
    }
    receipt_path = output_root / f"{stem}-build-receipt.json"
    receipt_path.write_text(
        json.dumps(receipt, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    return receipt


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "build")
    parser.add_argument("--test", action="store_true")
    arguments = parser.parse_args()
    try:
        receipt = build(arguments.output.resolve(), arguments.test)
    except (OSError, RuntimeError, subprocess.SubprocessError) as error:
        print(error, file=sys.stderr)
        return 1
    print(json.dumps(receipt, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

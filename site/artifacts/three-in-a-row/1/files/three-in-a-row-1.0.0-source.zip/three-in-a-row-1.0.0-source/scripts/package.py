#!/usr/bin/env python3

import argparse
import hashlib
import json
from pathlib import Path
import stat
import zipfile

from build import ROOT, build


VERSION = "1.0.0"
FIXED_TIME = (2026, 1, 1, 0, 0, 0)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def zip_info(name: str, executable: bool = False) -> zipfile.ZipInfo:
    value = zipfile.ZipInfo(name, FIXED_TIME)
    value.compress_type = zipfile.ZIP_STORED
    value.create_system = 3
    mode = 0o755 if executable else 0o644
    value.external_attr = (stat.S_IFREG | mode) << 16
    value.flag_bits = 0
    value.extra = b""
    value.comment = b""
    return value


def write_zip(path: Path, entries: list[tuple[str, bytes, bool]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", allowZip64=False) as archive:
        archive.comment = b""
        for name, data, executable in sorted(entries, key=lambda entry: entry[0]):
            archive.writestr(zip_info(name, executable), data)


def text_bytes(value: str) -> bytes:
    return value.replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")


def source_entries() -> list[tuple[str, bytes, bool]]:
    included = (
        ".github",
        "scripts",
        "src",
        "tests",
        ".gitattributes",
        ".gitignore",
        "BUILDING.md",
        "LICENSE",
        "README.md",
        "toolchain.lock.json",
    )
    files: list[Path] = []
    for item in included:
        path = ROOT / item
        if path.is_dir():
            files.extend(candidate for candidate in path.rglob("*") if candidate.is_file())
        elif path.is_file():
            files.append(path)
    result = []
    for path in sorted(set(files)):
        relative = path.relative_to(ROOT).as_posix()
        if "__pycache__" in path.parts or path.suffix == ".pyc":
            continue
        result.append((f"three-in-a-row-{VERSION}-source/{relative}", path.read_bytes(), False))
    return result


def file_record(path: Path) -> dict:
    return {
        "path": path.name,
        "bytes": path.stat().st_size,
        "sha256": sha256(path),
    }


def package(output_root: Path, build_root: Path) -> dict:
    receipt = build(build_root)
    executable = build_root / "THREE.COM"
    license_bytes = (ROOT / "LICENSE").read_bytes()
    readme = text_bytes(
        """Three in a Row 1.0.0

An original one-player tic-tac-toe game for DOS.

Run THREE.COM in a DOS-compatible environment. Use the mouse or touch to
select a cell. Arrow keys move focus, Enter marks a cell, F1 opens help,
and Escape exits. Completed-round win/draw/loss totals are stored locally.

Copyright (c) 2026 The Funky Bits. Licensed under the MIT License.
Source and build instructions: https://github.com/TheFunkyBits/three-in-a-row
"""
    )

    import_zip = output_root / f"three-in-a-row-{VERSION}-dos.zip"
    source_zip = output_root / f"three-in-a-row-{VERSION}-source.zip"
    wrapper = f"three-in-a-row-{VERSION}"
    write_zip(
        import_zip,
        [
            (f"{wrapper}/LICENSE.TXT", license_bytes, False),
            (f"{wrapper}/README.TXT", readme, False),
            (f"{wrapper}/THREE.COM", executable.read_bytes(), True),
        ],
    )
    write_zip(source_zip, source_entries())

    provenance = {
        "schemaVersion": 1,
        "title": "Three in a Row",
        "version": VERSION,
        "license": "MIT",
        "copyright": "Copyright (c) 2026 The Funky Bits",
        "thirdPartyRuntimeContent": False,
        "build": receipt,
        "artifacts": {
            "executable": file_record(executable),
            "manualImport": file_record(import_zip),
            "correspondingSource": file_record(source_zip),
        },
    }
    provenance_path = output_root / "provenance.json"
    provenance_path.write_text(
        json.dumps(provenance, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    checksums = output_root / "SHA256SUMS.txt"
    checksum_paths = (import_zip, source_zip, provenance_path)
    checksums.write_text(
        "".join(f"{sha256(path)}  {path.name}\n" for path in checksum_paths),
        encoding="ascii",
        newline="\n",
    )
    return provenance


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "dist")
    parser.add_argument("--build", type=Path, default=ROOT / "build" / "release")
    arguments = parser.parse_args()
    provenance = package(arguments.output.resolve(), arguments.build.resolve())
    print(json.dumps(provenance, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python3

from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
LOCAL_DOSBOX_X = (
    ROOT.parent
    / ".tools"
    / "dosbox-x-2026.07.02"
    / "bin"
    / "x64"
    / "Release SDL2"
    / "dosbox-x.exe"
)


def run(*arguments: str) -> None:
    subprocess.run(arguments, cwd=ROOT, check=True)


def main() -> int:
    run(sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v")
    run(sys.executable, "scripts/build.py", "--output", "build/shipping")
    run(sys.executable, "scripts/build.py", "--test", "--output", "build/selftest")
    if platform.system() == "Windows" and LOCAL_DOSBOX_X.is_file():
        run(
            "powershell",
            "-NoProfile",
            "-File",
            "scripts/dos-selftest.ps1",
            "-Binary",
            "build/selftest/TIRTEST.COM",
        )
    run(sys.executable, "scripts/package.py", "--output", "dist", "--build", "build/release")
    run(sys.executable, "scripts/verify_reproducible.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

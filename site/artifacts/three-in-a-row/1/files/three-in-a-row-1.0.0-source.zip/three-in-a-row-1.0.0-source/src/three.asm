bits 16
cpu 8086
org 0x100

jmp start

EMPTY equ 0
MARK_X equ 1
MARK_O equ 2

board: times 9 db EMPTY
winning_line: db 0xFF
temporary_cell: db 0
temporary_mark: db 0

%include "rules.inc"
%include "ai.inc"
%include "save.inc"
%include "input.inc"
%include "game.inc"
%include "video.inc"
%include "ui.inc"

%ifdef TEST_BUILD
%include "selftest.inc"
%endif

start:
    push cs
    pop ds
    push cs
    pop es

%ifdef TEST_BUILD
    call run_self_tests
    mov ax, 0x4C00
    int 0x21
%else
    cld
    mov ax, 0x0013
    int 0x10
    mov ax, 0xA000
    mov es, ax
    call set_game_palette
    call initialize_mouse
    call initialize_game
    call render_game

.main_loop:
    call tick_game
    call poll_mouse
    cmp al, INPUT_NONE
    je .keyboard
    call handle_input_event
.keyboard:
    call poll_keyboard
    cmp al, INPUT_NONE
    je .render
    call handle_input_event
.render:
    cmp byte [needs_render], 0
    je .check_exit
    call render_game
.check_exit:
    cmp byte [game_state], STATE_EXIT
    je .exit
    int 0x28
    jmp .main_loop

.exit:
    mov ax, 0x0003
    int 0x10
    mov ax, 0x4C00
    int 0x21
%endif


# Building

## Requirements

- Python 3.13 or newer, standard library only.
- Android NDK 25.1.8937393.
- The NDK-bundled Yasm 1.3.0 matching `toolchain.lock.json`.

On Windows, the build finds the Android SDK through `ANDROID_SDK_ROOT`, `ANDROID_HOME`, or `%LOCALAPPDATA%\Android\Sdk`.

## Commands

```powershell
python scripts/build.py
python -m unittest discover -s tests -v
python scripts/package.py
python scripts/verify_reproducible.py
python scripts/check.py
```

`THREE.COM` is a flat 8086-compatible DOS COM image. `TIRTEST.COM` is a non-shipping self-test image compiled from the same rules, AI, save, and input modules.

The media exporter accepts three reviewed native 320x200 PNG frames and writes 1280x960 square-pixel RGB assets:

```powershell
./scripts/export-media.ps1 -Cover cover-320x200.png -Gameplay gameplay-320x200.png -Statistics statistics-320x200.png -OutputDirectory media
```
